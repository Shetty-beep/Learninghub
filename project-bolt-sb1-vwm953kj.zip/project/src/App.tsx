import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import HomePage from './pages/HomePage';
import ModulesPage from './pages/ModulesPage';
import LoginPage from './pages/auth/LoginPage';
import AdminLoginPage from './pages/auth/AdminLoginPage';
import AffiliateLoginPage from './pages/auth/AffiliateLoginPage';
import AdminDashboard from './pages/admin/AdminDashboard';
import AffiliateDashboard from './pages/affiliate/AffiliateDashboard';
import { useAuthStore } from './store/authStore';

function App() {
  const { user } = useAuthStore();

  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/modules" element={<ModulesPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/admin/login" element={<AdminLoginPage />} />
            <Route path="/affiliate/login" element={<AffiliateLoginPage />} />
            
            {/* Protected Admin Routes */}
            {user?.role === 'admin' && (
              <Route path="/admin" element={<AdminDashboard />} />
            )}
            
            {/* Protected Affiliate Routes */}
            {user?.role === 'affiliate' && (
              <Route path="/affiliate" element={<AffiliateDashboard />} />
            )}
            
            {/* Add more routes as needed */}
          </Routes>
        </main>
        <Footer />
        <Toaster 
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: '#363636',
              color: '#fff',
            },
          }}
        />
      </div>
    </Router>
  );
}

export default App;