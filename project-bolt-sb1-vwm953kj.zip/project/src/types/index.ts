export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  role: 'learner' | 'admin' | 'affiliate';
  subscription?: Subscription;
  progress: ModuleProgress[];
  createdAt: Date;
}

export interface Subscription {
  id: string;
  plan: 'free' | 'single' | 'all' | 'lifetime';
  status: 'active' | 'canceled' | 'expired';
  moduleAccess: string[];
  expiresAt?: Date;
  createdAt: Date;
}

export interface Module {
  id: string;
  title: string;
  description: string;
  category: 'payments' | 'lending' | 'cards';
  isPremium: boolean;
  image: string;
  duration: number;
  chapters: Chapter[];
  tags: string[];
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  createdAt: Date;
  updatedAt: Date;
}

export interface Chapter {
  id: string;
  moduleId: string;
  title: string;
  content: string;
  isPremium: boolean;
  order: number;
  estimatedReadTime: number;
  createdAt: Date;
}

export interface BlogPost {
  id: string;
  title: string;
  content: string;
  excerpt: string;
  author: string;
  category: string;
  tags: string[];
  image: string;
  publishedAt: Date;
  readTime: number;
  isPremium: boolean;
}

export interface ModuleProgress {
  moduleId: string;
  completedChapters: string[];
  progressPercentage: number;
  lastAccessedAt: Date;
}

export interface Affiliate {
  id: string;
  name: string;
  email: string;
  bio?: string;
  avatar?: string;
  socialProfiles: {
    youtube?: string;
    linkedin?: string;
    twitter?: string;
    blog?: string;
  };
  preferredChannels: string[];
  affiliateCode: string;
  commissionRate: number;
  totalClicks: number;
  totalConversions: number;
  totalEarnings: number;
  pendingWithdrawal: number;
  bankDetails?: BankDetails;
  status: 'active' | 'suspended' | 'pending';
  createdAt: Date;
}

export interface BankDetails {
  accountNumber: string;
  routingNumber: string;
  accountName: string;
  bankName: string;
}

export interface AffiliateClick {
  id: string;
  affiliateId: string;
  clickedAt: Date;
  referrerUrl: string;
  targetUrl: string;
  ipAddress: string;
  userAgent: string;
  converted: boolean;
  conversionValue?: number;
}

export interface AnalyticsData {
  totalUsers: number;
  activeUsers: number;
  newSignups: number;
  conversionRate: number;
  revenue: number;
  popularModules: Array<{
    moduleId: string;
    title: string;
    views: number;
    completions: number;
  }>;
  affiliateStats: Array<{
    affiliateId: string;
    name: string;
    clicks: number;
    conversions: number;
    revenue: number;
  }>;
}