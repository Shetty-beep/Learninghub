import { create } from 'zustand';
import { User } from '../types';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  adminLogin: (email: string, password: string) => Promise<void>;
  affiliateLogin: (email: string, password: string) => Promise<void>;
  logout: () => void;
  updateUser: (userData: Partial<User>) => void;
}

// Mock user data for different roles
const mockUsers = {
  admin: {
    id: 'admin-1',
    email: 'admin@learnhub.com',
    name: 'Admin User',
    avatar: 'https://images.pexels.com/photos/771742/pexels-photo-771742.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
    role: 'admin' as const,
    progress: [],
    createdAt: new Date(),
  },
  affiliate: {
    id: 'affiliate-1',
    email: 'affiliate@example.com',
    name: 'Affiliate Partner',
    avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
    role: 'affiliate' as const,
    progress: [],
    createdAt: new Date(),
  },
  learner: {
    id: 'learner-1',
    email: 'user@example.com',
    name: 'John Doe',
    avatar: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
    role: 'learner' as const,
    progress: [],
    createdAt: new Date(),
  },
};

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  isAuthenticated: false,
  isLoading: false,

  login: async (email: string, password: string) => {
    set({ isLoading: true });
    try {
      // Mock authentication - replace with actual API call
      const mockUser: User = {
        ...mockUsers.learner,
        email,
      };
      
      set({ user: mockUser, isAuthenticated: true, isLoading: false });
    } catch (error) {
      set({ isLoading: false });
      throw error;
    }
  },

  adminLogin: async (email: string, password: string) => {
    set({ isLoading: true });
    try {
      // Mock admin authentication
      if (email === 'admin@learnhub.com' && password === 'admin123') {
        set({ user: mockUsers.admin, isAuthenticated: true, isLoading: false });
      } else {
        set({ isLoading: false });
        throw new Error('Invalid admin credentials');
      }
    } catch (error) {
      set({ isLoading: false });
      throw error;
    }
  },

  affiliateLogin: async (email: string, password: string) => {
    set({ isLoading: true });
    try {
      // Mock affiliate authentication
      if (email === 'affiliate@example.com' && password === 'affiliate123') {
        set({ user: mockUsers.affiliate, isAuthenticated: true, isLoading: false });
      } else {
        set({ isLoading: false });
        throw new Error('Invalid affiliate credentials');
      }
    } catch (error) {
      set({ isLoading: false });
      throw error;
    }
  },

  loginWithGoogle: async () => {
    set({ isLoading: true });
    try {
      // Mock Google authentication - replace with actual Firebase/OAuth
      set({ user: mockUsers.learner, isAuthenticated: true, isLoading: false });
    } catch (error) {
      set({ isLoading: false });
      throw error;
    }
  },

  logout: () => {
    set({ user: null, isAuthenticated: false });
  },

  updateUser: (userData: Partial<User>) => {
    const { user } = get();
    if (user) {
      set({ user: { ...user, ...userData } });
    }
  },
}));