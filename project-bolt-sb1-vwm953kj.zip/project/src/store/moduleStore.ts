import { create } from 'zustand';
import { Module, Chapter, ModuleProgress } from '../types';

interface ModuleState {
  modules: Module[];
  currentModule: Module | null;
  userProgress: ModuleProgress[];
  isLoading: boolean;
  fetchModules: () => Promise<void>;
  getModule: (id: string) => Module | undefined;
  updateProgress: (moduleId: string, chapterId: string) => void;
  getModuleProgress: (moduleId: string) => ModuleProgress | undefined;
}

const mockModules: Module[] = [
  {
    id: '1',
    title: 'Payment Systems Fundamentals',
    description: 'Learn the core concepts of payment processing, gateway integrations, and security protocols.',
    category: 'payments',
    isPremium: false,
    image: 'https://images.pexels.com/photos/4386321/pexels-photo-4386321.jpeg?auto=compress&cs=tinysrgb&w=800',
    duration: 120,
    difficulty: 'beginner',
    tags: ['payments', 'gateways', 'security'],
    chapters: [
      {
        id: '1-1',
        moduleId: '1',
        title: 'Introduction to Payment Systems',
        content: '# Introduction to Payment Systems\n\nPayment systems are the backbone of modern commerce...',
        isPremium: false,
        order: 1,
        estimatedReadTime: 15,
        createdAt: new Date(),
      },
      {
        id: '1-2',
        moduleId: '1',
        title: 'Payment Gateway Architecture',
        content: '# Payment Gateway Architecture\n\nUnderstanding how payment gateways work...',
        isPremium: true,
        order: 2,
        estimatedReadTime: 20,
        createdAt: new Date(),
      },
    ],
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: '2',
    title: 'Advanced Lending Strategies',
    description: 'Master risk assessment, credit scoring, and automated lending workflows.',
    category: 'lending',
    isPremium: true,
    image: 'https://images.pexels.com/photos/4386431/pexels-photo-4386431.jpeg?auto=compress&cs=tinysrgb&w=800',
    duration: 180,
    difficulty: 'advanced',
    tags: ['lending', 'risk', 'automation'],
    chapters: [
      {
        id: '2-1',
        moduleId: '2',
        title: 'Credit Risk Assessment',
        content: '# Credit Risk Assessment\n\nEvaluating borrower creditworthiness...',
        isPremium: true,
        order: 1,
        estimatedReadTime: 25,
        createdAt: new Date(),
      },
    ],
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: '3',
    title: 'Card Processing Essentials',
    description: 'Comprehensive guide to credit card processing, EMV, and fraud prevention.',
    category: 'cards',
    isPremium: false,
    image: 'https://images.pexels.com/photos/4386370/pexels-photo-4386370.jpeg?auto=compress&cs=tinysrgb&w=800',
    duration: 90,
    difficulty: 'intermediate',
    tags: ['cards', 'emv', 'fraud'],
    chapters: [
      {
        id: '3-1',
        moduleId: '3',
        title: 'Card Network Basics',
        content: '# Card Network Basics\n\nHow Visa, Mastercard, and other networks operate...',
        isPremium: false,
        order: 1,
        estimatedReadTime: 12,
        createdAt: new Date(),
      },
    ],
    createdAt: new Date(),
    updatedAt: new Date(),
  },
];

export const useModuleStore = create<ModuleState>((set, get) => ({
  modules: [],
  currentModule: null,
  userProgress: [],
  isLoading: false,

  fetchModules: async () => {
    set({ isLoading: true });
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      set({ modules: mockModules, isLoading: false });
    } catch (error) {
      set({ isLoading: false });
      throw error;
    }
  },

  getModule: (id: string) => {
    const { modules } = get();
    return modules.find(module => module.id === id);
  },

  updateProgress: (moduleId: string, chapterId: string) => {
    const { userProgress } = get();
    const existingProgress = userProgress.find(p => p.moduleId === moduleId);
    
    if (existingProgress) {
      if (!existingProgress.completedChapters.includes(chapterId)) {
        existingProgress.completedChapters.push(chapterId);
        existingProgress.lastAccessedAt = new Date();
      }
    } else {
      const newProgress: ModuleProgress = {
        moduleId,
        completedChapters: [chapterId],
        progressPercentage: 0,
        lastAccessedAt: new Date(),
      };
      userProgress.push(newProgress);
    }
    
    // Calculate progress percentage
    const module = get().getModule(moduleId);
    if (module && existingProgress) {
      existingProgress.progressPercentage = 
        (existingProgress.completedChapters.length / module.chapters.length) * 100;
    }
    
    set({ userProgress: [...userProgress] });
  },

  getModuleProgress: (moduleId: string) => {
    const { userProgress } = get();
    return userProgress.find(p => p.moduleId === moduleId);
  },
}));