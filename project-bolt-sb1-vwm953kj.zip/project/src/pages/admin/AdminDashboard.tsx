import React from 'react';
import { motion } from 'framer-motion';
import { Users, BookOpen, DollarSign, TrendingUp, Eye, Edit, Trash2 } from 'lucide-react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Badge from '../../components/ui/Badge';

const AdminDashboard: React.FC = () => {
  const stats = [
    {
      title: 'Total Users',
      value: '10,247',
      change: '+12%',
      icon: Users,
      color: 'text-primary-600',
      bgColor: 'bg-primary-100',
    },
    {
      title: 'Active Modules',
      value: '24',
      change: '+3',
      icon: BookOpen,
      color: 'text-secondary-600',
      bgColor: 'bg-secondary-100',
    },
    {
      title: 'Monthly Revenue',
      value: '$45,230',
      change: '+18%',
      icon: DollarSign,
      color: 'text-success-600',
      bgColor: 'bg-success-100',
    },
    {
      title: 'Conversion Rate',
      value: '3.2%',
      change: '+0.5%',
      icon: TrendingUp,
      color: 'text-accent-600',
      bgColor: 'bg-accent-100',
    },
  ];

  const recentModules = [
    {
      id: '1',
      title: 'Advanced Payment Processing',
      category: 'Payments',
      status: 'Published',
      views: 1250,
      createdAt: '2024-01-15',
    },
    {
      id: '2',
      title: 'Credit Risk Assessment',
      category: 'Lending',
      status: 'Draft',
      views: 0,
      createdAt: '2024-01-14',
    },
    {
      id: '3',
      title: 'EMV Card Security',
      category: 'Cards',
      status: 'Published',
      views: 890,
      createdAt: '2024-01-13',
    },
  ];

  const recentUsers = [
    {
      id: '1',
      name: 'Sarah Johnson',
      email: 'sarah@example.com',
      plan: 'Premium',
      joinedAt: '2024-01-15',
    },
    {
      id: '2',
      name: 'Mike Chen',
      email: 'mike@example.com',
      plan: 'Free',
      joinedAt: '2024-01-14',
    },
    {
      id: '3',
      name: 'Emily Davis',
      email: 'emily@example.com',
      plan: 'Lifetime',
      joinedAt: '2024-01-13',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-display font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-600 mt-2">Manage your learning platform</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card>
                <div className="flex items-center">
                  <div className={`p-3 rounded-lg ${stat.bgColor}`}>
                    <stat.icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                    <div className="flex items-center">
                      <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                      <span className="ml-2 text-sm font-medium text-success-600">
                        {stat.change}
                      </span>
                    </div>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Recent Modules */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Card>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-900">Recent Modules</h2>
                <Button size="sm">View All</Button>
              </div>
              <div className="space-y-4">
                {recentModules.map((module) => (
                  <div key={module.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900">{module.title}</h3>
                      <div className="flex items-center space-x-4 mt-1">
                        <Badge variant="default" size="sm">{module.category}</Badge>
                        <Badge 
                          variant={module.status === 'Published' ? 'success' : 'warning'} 
                          size="sm"
                        >
                          {module.status}
                        </Badge>
                        <span className="text-sm text-gray-500">{module.views} views</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button variant="ghost" size="sm" icon={<Eye className="w-4 h-4" />} />
                      <Button variant="ghost" size="sm" icon={<Edit className="w-4 h-4" />} />
                      <Button variant="ghost" size="sm" icon={<Trash2 className="w-4 h-4" />} />
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </motion.div>

          {/* Recent Users */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Card>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-900">Recent Users</h2>
                <Button size="sm">View All</Button>
              </div>
              <div className="space-y-4">
                {recentUsers.map((user) => (
                  <div key={user.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-primary-500 rounded-full flex items-center justify-center">
                        <span className="text-white font-medium">
                          {user.name.split(' ').map(n => n[0]).join('')}
                        </span>
                      </div>
                      <div className="ml-3">
                        <p className="font-medium text-gray-900">{user.name}</p>
                        <p className="text-sm text-gray-500">{user.email}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge 
                        variant={user.plan === 'Free' ? 'default' : user.plan === 'Premium' ? 'primary' : 'premium'}
                        size="sm"
                      >
                        {user.plan}
                      </Badge>
                      <p className="text-xs text-gray-500 mt-1">{user.joinedAt}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;