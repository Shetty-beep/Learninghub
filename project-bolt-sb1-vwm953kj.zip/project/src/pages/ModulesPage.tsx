import React, { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, Filter, BookOpen, Clock, Users, Star, Lock, Play } from 'lucide-react';
import { useModuleStore } from '../store/moduleStore';
import { useAuthStore } from '../store/authStore';
import Card from '../components/ui/Card';
import Badge from '../components/ui/Badge';
import Button from '../components/ui/Button';

const ModulesPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get('category') || 'all');
  const [selectedDifficulty, setSelectedDifficulty] = useState('all');
  const [showFilters, setShowFilters] = useState(false);

  const { modules, isLoading, fetchModules, getModuleProgress } = useModuleStore();
  const { user, isAuthenticated } = useAuthStore();

  useEffect(() => {
    fetchModules();
  }, [fetchModules]);

  const categories = [
    { value: 'all', label: 'All Categories' },
    { value: 'payments', label: 'Payment Systems' },
    { value: 'lending', label: 'Lending & Credit' },
    { value: 'cards', label: 'Card Processing' },
  ];

  const difficulties = [
    { value: 'all', label: 'All Levels' },
    { value: 'beginner', label: 'Beginner' },
    { value: 'intermediate', label: 'Intermediate' },
    { value: 'advanced', label: 'Advanced' },
  ];

  const filteredModules = modules.filter(module => {
    const matchesSearch = module.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         module.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || module.category === selectedCategory;
    const matchesDifficulty = selectedDifficulty === 'all' || module.difficulty === selectedDifficulty;
    
    return matchesSearch && matchesCategory && matchesDifficulty;
  });

  const canAccessModule = (module: any) => {
    if (!module.isPremium) return true;
    if (!isAuthenticated) return false;
    
    // Check if user has subscription that includes this module
    return user?.subscription?.moduleAccess?.includes(module.id) || 
           user?.subscription?.plan === 'all' || 
           user?.subscription?.plan === 'lifetime';
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'success';
      case 'intermediate': return 'warning';
      case 'advanced': return 'error';
      default: return 'default';
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 border-4 border-primary-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Loading modules...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-3xl lg:text-4xl font-display font-bold text-gray-900 mb-4">
              Learning Modules
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl">
              Master fintech concepts with our comprehensive, expert-crafted modules
            </p>
          </motion.div>
        </div>

        {/* Search and Filters */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search modules..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              />
            </div>

            {/* Filter Toggle */}
            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              icon={<Filter className="w-4 h-4" />}
            >
              Filters
            </Button>
          </div>

          {/* Filter Options */}
          {showFilters && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="bg-white rounded-lg p-6 border border-gray-200"
            >
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Category
                  </label>
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  >
                    {categories.map(category => (
                      <option key={category.value} value={category.value}>
                        {category.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Difficulty Level
                  </label>
                  <select
                    value={selectedDifficulty}
                    onChange={(e) => setSelectedDifficulty(e.target.value)}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  >
                    {difficulties.map(difficulty => (
                      <option key={difficulty.value} value={difficulty.value}>
                        {difficulty.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </motion.div>
          )}
        </div>

        {/* Results Count */}
        <div className="mb-6">
          <p className="text-gray-600">
            Showing {filteredModules.length} of {modules.length} modules
          </p>
        </div>

        {/* Modules Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredModules.map((module, index) => {
            const canAccess = canAccessModule(module);
            const progress = getModuleProgress(module.id);
            
            return (
              <motion.div
                key={module.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="h-full group">
                  <div className="relative">
                    <img
                      src={module.image}
                      alt={module.title}
                      className="w-full h-48 object-cover rounded-lg group-hover:scale-105 transition-transform duration-300"
                    />
                    
                    {/* Overlay */}
                    <div className="absolute inset-0 bg-black/40 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                      {canAccess ? (
                        <Play className="w-12 h-12 text-white" />
                      ) : (
                        <Lock className="w-12 h-12 text-white" />
                      )}
                    </div>

                    {/* Badges */}
                    <div className="absolute top-3 left-3 flex space-x-2">
                      <Badge variant={getDifficultyColor(module.difficulty)}>
                        {module.difficulty}
                      </Badge>
                      {module.isPremium && (
                        <Badge variant="premium">Premium</Badge>
                      )}
                    </div>

                    {/* Progress */}
                    {progress && (
                      <div className="absolute bottom-3 left-3 right-3">
                        <div className="bg-white/90 rounded-full h-2">
                          <div
                            className="bg-primary-500 h-2 rounded-full transition-all duration-300"
                            style={{ width: `${progress.progressPercentage}%` }}
                          ></div>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="p-6">
                    <div className="mb-4">
                      <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-primary-600 transition-colors">
                        {module.title}
                      </h3>
                      <p className="text-gray-600 text-sm line-clamp-2">
                        {module.description}
                      </p>
                    </div>

                    <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        {module.duration} min
                      </div>
                      <div className="flex items-center">
                        <BookOpen className="w-4 h-4 mr-1" />
                        {module.chapters.length} chapters
                      </div>
                      <div className="flex items-center">
                        <Star className="w-4 h-4 mr-1 text-warning-400" />
                        4.8
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-1 mb-4">
                      {module.tags.slice(0, 3).map((tag, tagIndex) => (
                        <Badge key={tagIndex} variant="default" size="sm">
                          {tag}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex items-center justify-between">
                      {canAccess || !module.isPremium ? (
                        <Link
                          to={`/modules/${module.id}`}
                          className="flex-1"
                        >
                          <Button className="w-full">
                            {progress ? 'Continue Learning' : 'Start Learning'}
                          </Button>
                        </Link>
                      ) : (
                        <div className="flex-1 space-y-2">
                          <Button variant="outline" className="w-full">
                            Preview Free Content
                          </Button>
                          <Link to="/pricing">
                            <Button className="w-full text-sm">
                              Unlock Premium
                            </Button>
                          </Link>
                        </div>
                      )}
                    </div>
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Empty State */}
        {filteredModules.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-medium text-gray-900 mb-2">
              No modules found
            </h3>
            <p className="text-gray-600 mb-6">
              Try adjusting your search criteria or browse all modules
            </p>
            <Button onClick={() => {
              setSearchTerm('');
              setSelectedCategory('all');
              setSelectedDifficulty('all');
            }}>
              Clear Filters
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default ModulesPage;