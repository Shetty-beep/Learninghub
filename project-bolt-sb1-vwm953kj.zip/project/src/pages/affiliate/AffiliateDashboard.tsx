import React from 'react';
import { motion } from 'framer-motion';
import { DollarSign, Users, MousePointer, TrendingUp, Copy, ExternalLink } from 'lucide-react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Badge from '../../components/ui/Badge';
import toast from 'react-hot-toast';

const AffiliateDashboard: React.FC = () => {
  const stats = [
    {
      title: 'Total Earnings',
      value: '$2,450',
      change: '+15%',
      icon: DollarSign,
      color: 'text-success-600',
      bgColor: 'bg-success-100',
    },
    {
      title: 'Total Clicks',
      value: '1,247',
      change: '+8%',
      icon: MousePointer,
      color: 'text-primary-600',
      bgColor: 'bg-primary-100',
    },
    {
      title: 'Conversions',
      value: '89',
      change: '+12%',
      icon: Users,
      color: 'text-secondary-600',
      bgColor: 'bg-secondary-100',
    },
    {
      title: 'Conversion Rate',
      value: '7.1%',
      change: '+0.3%',
      icon: TrendingUp,
      color: 'text-accent-600',
      bgColor: 'bg-accent-100',
    },
  ];

  const affiliateLinks = [
    {
      id: '1',
      title: 'Payment Systems Course',
      url: 'https://learnhub.com/modules/payments?ref=AFF123',
      clicks: 245,
      conversions: 12,
      earnings: '$360',
    },
    {
      id: '2',
      title: 'Lending Fundamentals',
      url: 'https://learnhub.com/modules/lending?ref=AFF123',
      clicks: 189,
      conversions: 8,
      earnings: '$240',
    },
    {
      id: '3',
      title: 'Card Processing Guide',
      url: 'https://learnhub.com/modules/cards?ref=AFF123',
      clicks: 156,
      conversions: 6,
      earnings: '$180',
    },
  ];

  const recentActivity = [
    {
      id: '1',
      type: 'conversion',
      description: 'New user signed up via Payment Systems link',
      amount: '$30',
      timestamp: '2 hours ago',
    },
    {
      id: '2',
      type: 'click',
      description: 'Click on Lending Fundamentals link',
      amount: null,
      timestamp: '4 hours ago',
    },
    {
      id: '3',
      type: 'conversion',
      description: 'User upgraded to premium via Card Processing link',
      amount: '$45',
      timestamp: '1 day ago',
    },
  ];

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Link copied to clipboard!');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-display font-bold text-gray-900">Affiliate Dashboard</h1>
          <p className="text-gray-600 mt-2">Track your performance and earnings</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card>
                <div className="flex items-center">
                  <div className={`p-3 rounded-lg ${stat.bgColor}`}>
                    <stat.icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                    <div className="flex items-center">
                      <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                      <span className="ml-2 text-sm font-medium text-success-600">
                        {stat.change}
                      </span>
                    </div>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Affiliate Links */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Card>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-900">Your Affiliate Links</h2>
                <Button size="sm">Create New Link</Button>
              </div>
              <div className="space-y-4">
                {affiliateLinks.map((link) => (
                  <div key={link.id} className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-medium text-gray-900">{link.title}</h3>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          icon={<Copy className="w-4 h-4" />}
                          onClick={() => copyToClipboard(link.url)}
                        />
                        <Button
                          variant="ghost"
                          size="sm"
                          icon={<ExternalLink className="w-4 h-4" />}
                        />
                      </div>
                    </div>
                    <div className="text-sm text-gray-600 mb-3 font-mono bg-white p-2 rounded border">
                      {link.url}
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex space-x-4">
                        <span className="text-gray-600">{link.clicks} clicks</span>
                        <span className="text-gray-600">{link.conversions} conversions</span>
                      </div>
                      <Badge variant="success">{link.earnings}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </motion.div>

          {/* Recent Activity */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Card>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-900">Recent Activity</h2>
                <Button size="sm" variant="outline">View All</Button>
              </div>
              <div className="space-y-4">
                {recentActivity.map((activity) => (
                  <div key={activity.id} className="flex items-start space-x-3 p-4 bg-gray-50 rounded-lg">
                    <div className={`w-2 h-2 rounded-full mt-2 ${
                      activity.type === 'conversion' ? 'bg-success-500' : 'bg-primary-500'
                    }`}></div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-900">{activity.description}</p>
                      <p className="text-xs text-gray-500 mt-1">{activity.timestamp}</p>
                    </div>
                    {activity.amount && (
                      <Badge variant="success" size="sm">{activity.amount}</Badge>
                    )}
                  </div>
                ))}
              </div>
            </Card>
          </motion.div>
        </div>

        {/* Withdrawal Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-8"
        >
          <Card>
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-gray-900">Pending Withdrawal</h2>
                <p className="text-gray-600 mt-1">Available balance: $2,450</p>
              </div>
              <Button>Request Withdrawal</Button>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default AffiliateDashboard;